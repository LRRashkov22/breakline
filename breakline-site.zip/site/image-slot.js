/**
 * <image-slot> — a photo placeholder the site owner can fill by dragging a
 * picture onto it (or clicking to browse), standing in until the real media
 * library exists.
 *
 * Slots sharing an id share an image, so a photo dropped on a service card
 * also shows in that service's album viewer and thumbnail. Images are
 * downscaled, encoded as WebP and kept in localStorage; when that is full or
 * unavailable they still show for the session.
 *
 * Attributes: id (storage key), placeholder (empty-state caption),
 * src (fallback image), fit (cover | contain, default cover).
 */
(() => {
  const STORE_KEY = 'breakline.image-slots';
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];
  const MAX_DIM = 1200;

  const subs = new Set();
  let store = {};
  try {
    const raw = localStorage.getItem(STORE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if (parsed && typeof parsed === 'object') store = parsed;
  } catch (e) { /* private mode or corrupt value — start empty */ }

  function setSlot(id, url) {
    if (!id) return;
    if (url) store[id] = url;
    else delete store[id];
    subs.forEach((fn) => fn());
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(store));
    } catch (e) { /* out of quota — the drop still shows for this session */ }
  }

  async function encode(file, targetWidth) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.round(targetWidth * 2) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      if (bitmap.close) bitmap.close();
    }
  }

  const CSS = `
    :host { display:block; position:relative; width:100%; height:100%;
            font:400 14px/1.4 var(--font-sans, system-ui, sans-serif);
            color:var(--slate-600, #475569); }
    .frame { position:absolute; inset:0; overflow:hidden; background:var(--slate-100, #F1F5F9); }
    img { width:100%; height:100%; object-fit:cover; display:none; -webkit-user-drag:none; }
    :host([fit="contain"]) img { object-fit:contain; }
    :host([data-filled]) img { display:block; }
    .empty { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center;
             justify-content:center; gap:6px; padding:16px; text-align:center;
             cursor:pointer; user-select:none; }
    :host([data-filled]) .empty, :host([data-locked]) .empty { display:none; }
    .empty svg { opacity:.5; }
    .caption { max-width:90%; font-weight:600; }
    .browse { font-size:13px; opacity:.8; }
    .ring { position:absolute; inset:0; pointer-events:none;
            border:1.5px dashed var(--slate-300, #CBD5E1); }
    :host([data-filled]) .ring { display:none; }
    :host([data-over]) .ring { border-color:var(--brand-green, #0B7A4B); border-style:solid; }
    :host([data-over]) .frame { background:var(--brand-green-050, #F0F7F3); }
    /* visibility, not opacity alone: hidden controls must stay out of the
       tab order, or they read as two unlabelled stops inside the album. */
    .controls { position:absolute; top:8px; right:8px; display:flex; gap:6px;
                visibility:hidden; opacity:0; transition:opacity 120ms; }
    :host([data-filled]:hover) .controls { visibility:visible; opacity:1; }
    :host([data-locked]) .controls { display:none; }
    .controls button { border:0; border-radius:6px; padding:6px 10px; cursor:pointer;
                       background:rgba(15,26,36,.72); color:#fff;
                       font:600 12px/1 var(--font-sans, system-ui, sans-serif); }
    .controls button:hover { background:rgba(15,26,36,.88); }
    .error { position:absolute; left:8px; right:8px; bottom:8px; padding:6px 8px; border-radius:6px;
             background:rgba(255,255,255,.92); color:var(--danger, #B42318);
             font-size:13px; pointer-events:none; }
    @media (prefers-reduced-motion: reduce) { .controls { transition:none; } }
  `;

  const ICON =
    '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' +
    '<path d="m21 15-5-5L5 21"/></svg>';

  class ImageSlot extends HTMLElement {
    static get observedAttributes() { return ['placeholder', 'src', 'id']; }

    constructor() {
      super();
      const root = this.attachShadow({ mode: 'open' });
      root.innerHTML =
        '<style>' + CSS + '</style>' +
        '<div class="frame">' +
        '  <img alt="" draggable="false">' +
        '  <div class="empty">' + ICON +
        '    <div class="caption"></div>' +
        '    <div class="browse">or browse files</div>' +
        '  </div>' +
        '  <div class="ring"></div>' +
        '</div>' +
        '<div class="controls">' +
        '  <button type="button" data-act="replace">Replace</button>' +
        '  <button type="button" data-act="remove">Remove</button>' +
        '</div>' +
        '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';

      this._img = root.querySelector('img');
      this._caption = root.querySelector('.caption');
      this._input = root.querySelector('input');
      this._error = null;
      this._depth = 0;
      this._onStore = () => this.render();

      root.querySelector('.empty').addEventListener('click', () => this._input.click());
      root.querySelector('.controls').addEventListener('click', (e) => {
        const act = e.target.dataset && e.target.dataset.act;
        if (act === 'replace') this._input.click();
        if (act === 'remove') setSlot(this.id, null);
      });
      this._input.addEventListener('change', () => {
        const file = this._input.files && this._input.files[0];
        if (file) this.ingest(file);
        this._input.value = '';
      });
    }

    connectedCallback() {
      // Inside a button (the album thumbnails) the slot only receives drops:
      // its own controls would be interactive content nested in a button, and
      // the click belongs to the thumbnail.
      this.toggleAttribute('data-locked', !!this.closest('button'));
      ['dragenter', 'dragover', 'dragleave', 'drop'].forEach((t) => this.addEventListener(t, this));
      subs.add(this._onStore);
      this.render();
    }

    disconnectedCallback() {
      ['dragenter', 'dragover', 'dragleave', 'drop'].forEach((t) => this.removeEventListener(t, this));
      subs.delete(this._onStore);
    }

    attributeChangedCallback() {
      if (this.shadowRoot) this.render();
    }

    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        e.preventDefault();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        if (--this._depth <= 0) { this._depth = 0; this.removeAttribute('data-over'); }
      } else if (e.type === 'drop') {
        e.preventDefault();
        this._depth = 0;
        this.removeAttribute('data-over');
        const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (file) this.ingest(file);
      }
    }

    async ingest(file) {
      this.setError(null);
      if (ACCEPT.indexOf(file.type) < 0) {
        this.setError('Drop a PNG, JPEG, WebP or AVIF image.');
        return;
      }
      try {
        setSlot(this.id, await encode(file, this.clientWidth || MAX_DIM));
      } catch (err) {
        this.setError('Could not read that image.');
      }
    }

    setError(message) {
      if (this._error) { this._error.remove(); this._error = null; }
      if (!message) return;
      const el = document.createElement('div');
      el.className = 'error';
      el.textContent = message;
      this.shadowRoot.append(el);
      this._error = el;
      setTimeout(() => { if (this._error === el) { el.remove(); this._error = null; } }, 3000);
    }

    render() {
      this._caption.textContent = this.getAttribute('placeholder') || 'Drop an image';
      const url = (this.id && store[this.id]) || this.getAttribute('src') || '';
      if (url) {
        if (this._img.getAttribute('src') !== url) this._img.src = url;
        this.setAttribute('data-filled', '');
      } else {
        this._img.removeAttribute('src');
        this.removeAttribute('data-filled');
      }
    }
  }

  if (!customElements.get('image-slot')) customElements.define('image-slot', ImageSlot);
})();
