/* BreakLine — public site behavior: the call popup and the per-service album. */

(() => {
  const mediaList = (slug, kinds, labels) =>
    kinds.map((kind, i) => ({
      id: slug + '-m' + (i + 1),
      kind,
      label: labels[i],
      caption: (kind === 'video' ? 'Video' : 'Photo') + ' · ' + labels[i],
    }));

  const SERVICES = {
    wall: {
      title: 'Wall demolition',
      media: mediaList('wall', ['photo', 'video', 'photo', 'photo', 'video', 'photo'], [
        'Before — brick partition, Lozenets',
        'Wall coming down, dust screens up',
        'Half-way through',
        'Opening cleared',
        'Debris carried out',
        'Room swept and handed over',
      ]),
    },
    drill: {
      title: 'Concrete drilling',
      media: mediaList('drill', ['video', 'photo', 'photo', 'photo', 'video'], [
        '160 mm core drill, water cooled',
        'Finished hole for kitchen vent',
        'Six holes, slab ceiling',
        'Cable route through concrete',
        'Wet drilling — no dust in the flat',
      ]),
    },
    cut: {
      title: 'Openings and cutting',
      media: mediaList('cut', ['photo', 'photo', 'video', 'photo', 'photo', 'video'], [
        'Marked out before cutting',
        'Steel lintel fitted',
        'Wall saw at work',
        'New door opening, 90 × 210 cm',
        'Edges finished ready for frame',
        'Load-bearing opening, engineer approved',
      ]),
    },
    bath: {
      title: 'Bathroom and tile strip-out',
      media: mediaList('bath', ['photo', 'photo', 'video', 'photo', 'photo'], [
        'Old bathroom, before',
        'Tiles and screed off',
        'Strip-out in progress',
        'Old pipework removed',
        'Bare walls, ready for waterproofing',
      ]),
    },
    debris: {
      title: 'Debris removal',
      media: mediaList('debris', ['photo', 'photo', 'video', 'photo'], [
        'Bagged and stacked',
        'Loading the van',
        'Carry-down from fourth floor',
        'Site swept, keys back',
      ]),
    },
    repair: {
      title: 'Small repairs after us',
      media: mediaList('repair', ['photo', 'photo', 'photo', 'video'], [
        'Patched around new opening',
        'Plastered and sanded',
        'Door frame refitted',
        'Finishing pass',
      ]),
    },
  };

  const countLabel = (media) => {
    const photos = media.filter((m) => m.kind === 'photo').length;
    const videos = media.length - photos;
    return photos + ' photos · ' + videos + (videos === 1 ? ' video' : ' videos');
  };

  const albumScrim = document.getElementById('album-scrim');
  const callScrim = document.getElementById('call-scrim');
  const albumDialog = albumScrim.querySelector('.album');
  const callDialog = callScrim.querySelector('.call-dialog');
  const albumTitle = albumScrim.querySelector('.album__title');
  const albumCount = albumScrim.querySelector('.album__count');
  const viewerMedia = albumScrim.querySelector('.viewer__media');
  const captionText = albumScrim.querySelector('.caption-row__text');
  const captionPos = albumScrim.querySelector('.caption-row__pos');
  const thumbStrip = albumScrim.querySelector('.thumbs');

  let album = null;   // { title, media } while open
  let index = 0;
  const returnFocus = { album: null, call: null };

  const slot = (id, placeholder) => {
    const el = document.createElement('image-slot');
    el.id = id;
    el.setAttribute('placeholder', placeholder);
    return el;
  };

  const playBadge = (size) => {
    const wrap = document.createElement('span');
    wrap.className = 'play-badge play-badge--' + size;
    wrap.innerHTML = '<span><svg class="icon" aria-hidden="true"><use href="#i-play"></use></svg></span>';
    return wrap;
  };

  /* ── Album ───────────────────────────────────────────────── */

  function renderViewer() {
    const item = album.media[index];
    viewerMedia.replaceChildren(slot(item.id, 'Drop photo or video poster here'));
    if (item.kind === 'video') viewerMedia.append(playBadge('lg'));
    captionText.textContent = item.caption;
    captionPos.textContent = index + 1 + ' of ' + album.media.length;
    thumbStrip.querySelectorAll('.thumb').forEach((btn, i) => {
      btn.setAttribute('aria-current', String(i === index));
    });
  }

  function renderThumbs() {
    thumbStrip.replaceChildren(
      ...album.media.map((item, i) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'thumb';
        btn.setAttribute('aria-label', item.caption);
        btn.append(slot(item.id, ' '));
        if (item.kind === 'video') btn.append(playBadge('sm'));
        btn.addEventListener('click', () => {
          index = i;
          renderViewer();
        });
        return btn;
      })
    );
  }

  function openAlbum(slug, trigger) {
    album = SERVICES[slug];
    if (!album) return;
    index = 0;
    returnFocus.album = trigger || null;
    albumTitle.textContent = album.title;
    albumCount.textContent = countLabel(album.media) + ' from our own jobs';
    renderThumbs();
    renderViewer();
    albumScrim.hidden = false;
    albumDialog.focus();
  }

  function closeAlbum() {
    if (!album) return;
    album = null;
    albumScrim.hidden = true;
    viewerMedia.replaceChildren();
    thumbStrip.replaceChildren();
    if (returnFocus.album) returnFocus.album.focus();
    returnFocus.album = null;
  }

  function step(delta) {
    if (!album) return;
    const n = album.media.length;
    index = (index + delta + n) % n;
    renderViewer();
  }

  /* ── Call popup ──────────────────────────────────────────── */

  function openCall(trigger) {
    returnFocus.call = trigger || null;
    callScrim.hidden = false;
    callDialog.focus();
  }

  function closeCall() {
    if (callScrim.hidden) return;
    callScrim.hidden = true;
    if (returnFocus.call) returnFocus.call.focus();
    returnFocus.call = null;
  }

  /* ── Wiring ──────────────────────────────────────────────── */

  document.addEventListener('click', (e) => {
    const callTrigger = e.target.closest('[data-call]');
    if (callTrigger) {
      openCall(callTrigger);
      return;
    }
    const albumTrigger = e.target.closest('[data-album]');
    if (albumTrigger) {
      openAlbum(albumTrigger.dataset.album, albumTrigger);
      return;
    }
    if (e.target.closest('[data-album-close]')) closeAlbum();
    if (e.target.closest('[data-call-close]')) closeCall();
    if (e.target === albumScrim) closeAlbum();
    if (e.target === callScrim) closeCall();
  });

  albumScrim.querySelector('.viewer__nav--prev').addEventListener('click', () => step(-1));
  albumScrim.querySelector('.viewer__nav--next').addEventListener('click', () => step(1));

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeCall();
      closeAlbum();
      return;
    }
    if (!album || !callScrim.hidden) return;
    if (e.key === 'ArrowRight') step(1);
    if (e.key === 'ArrowLeft') step(-1);
  });

  /* Keep Tab inside whichever dialog is on top. */
  const FOCUSABLE = 'a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])';
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    const dialog = !callScrim.hidden ? callDialog : album ? albumDialog : null;
    if (!dialog) return;
    const items = [...dialog.querySelectorAll(FOCUSABLE)].filter((el) => el.offsetParent !== null);
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (e.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  });
})();
